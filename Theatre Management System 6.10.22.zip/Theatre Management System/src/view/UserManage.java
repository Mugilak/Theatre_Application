package view;

public class UserManage {

	public void view() {
		
	}

}
