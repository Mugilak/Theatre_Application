package controller;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import database.Cinema;
import model.CinemaDatabase;
import model.Location;
import model.Screen;
import model.ShowTime;
import model.Theatre;
import model.User;
import view.AdminManage;

public class ManageController {
	private CinemaDatabase cinemaDB = CinemaDatabase.getInstance();
	private Cinema cinema = Cinema.getInstance();
	private String query;

	public User checkUser(String userName) {
		List<User> users = cinemaDB.getUserList();
		for (int index = 0; index < users.size(); index++) {
			User eachUser = users.get(index);
			if (eachUser.getUserName().equals(userName)) {
				return eachUser;
			}
		}
		return null;
	}

	public Location checkLocation(int locationId) {
		List<Location> locations = cinemaDB.getLocationList();

		for (int index = 0; index < locations.size(); index++) {
			Location eachLocation = locations.get(index);
			if ((eachLocation.getLocationId()) == (locationId)) {
				return eachLocation;
			}
		}
		return null;
	}

	public Location checkLocation(String location) {
		List<Location> locations = cinemaDB.getLocationList();

		for (int index = 0; index < locations.size(); index++) {
			Location eachLocation = locations.get(index);
			if ((eachLocation.getLocation().equals(location))) {
				return eachLocation;
			}
		}
		return null;
	}

	public Theatre checkTheatre(int theatreId) {
		List<Theatre> theatre = cinemaDB.getTheatreList();

		for (int index = 0; index < theatre.size(); index++) {
			Theatre eachTheatre = theatre.get(index);
			if (eachTheatre.getTheatreId() == theatreId) {
				return eachTheatre;
			}
		}
		return null;
	}

	public Screen checkScreen(int screenId) {
		List<Screen> screens = cinemaDB.getScreenList();

		for (int index = 0; index < screens.size(); index++) {
			Screen eachScreen = screens.get(index);
			if (eachScreen.getScreenId() == screenId) {
				return eachScreen;
			}
		}
		return null;
	}

	public boolean isValid(String regex, String word) {
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(word);
		if (match.find()) {
			return true;
		}
		return false;
	}

	public boolean updateMovies(String screenId, String showTime, String movieName, Screen screen) {
		showTime = giveTime(showTime);
		List<ShowTime> showList = cinemaDB.getShowsList();
		for (int index = 0; index < showList.size(); index++) {
			ShowTime eachShow = showList.get(index);
			if (eachShow.getShowTime().equals(showTime)) {
				addShows(screenId,showTime,movieName,screen);
				return true;
			}
		}
		return false;
	}

	private String giveTime(String showTime) {
		if (showTime == "1") {
			return "8:00";
		} else if (showTime == "2") {
			return "12:00";
		} else if (showTime == "3") {
			return "16:00";
		} else if (showTime == "4") {
			return "20:30";
		} else if (showTime == "5") {
			return "1:00";
		}
		return null;
	}

	public void addShows(String screenId, String showTime, String movieName, Screen screen) {
		showTime = giveTime(showTime);
		ShowTime shows = new ShowTime(Integer.valueOf(screenId), showTime, movieName);
		screen.setShowTime(shows);
		cinemaDB.addShowsList(shows);
		query = "insert into shows " + "values('" + shows.getScreenId() + "','" + shows.getShowTime() + "','"
				+ shows.getMovieName() + "')";
		cinema.setData(query);
	}

	public void addScreen(Screen screen, Theatre theatre, String theatreId, String screenId, String noOfSeats) {
		screen = new Screen(Integer.valueOf(theatreId), Integer.valueOf(screenId), Integer.valueOf(noOfSeats));
		theatre.setScreen(screen);
		cinemaDB.addScreenList(screen);

		query = "insert into screenlist " + "values('" + screen.getTheatreId() + "','" + screen.getScreenId() + "','"
				+ screen.getSeats() + "')";
		cinema.setData(query);
	}

	public void addTheatre(String theatreId, String theatreName, String locationId, Location locations) {
		Theatre theatre = new Theatre(Integer.valueOf(theatreId), theatreName, Integer.valueOf(locationId));
		locations.setTheatre(theatre);
		cinemaDB.addTheatreList(theatre);
		query = "insert into theatrelist " + "values('" + theatre.getTheatreId() + "','" + theatre.getTheatreName()
				+ "','" + theatre.getLocationId() + "')";
		cinema.setData(query);
	}

	public void addLocation(String locationId, String location) {
		Location locations = new Location(Integer.valueOf(locationId), location);
		cinemaDB.addLocationList(locations);
		query = "insert into location " + "values('" + locations.getLocationId() + "','" + locations.getLocation()
				+ "')";
		cinema.setData(query);
	}

}
