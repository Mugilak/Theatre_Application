package model;

import java.util.ArrayList;
import java.util.List;

public class CinemaDatabase {
	private static CinemaDatabase cinemaDB;
	private List<Location> locationList;
	private List<User> userList;
	private List<Admin> adminList;
	private List<Theatre> theatreList;
	private List<Screen> screenList;
	private List<ShowTime> showTimeList;

	private CinemaDatabase() {
		locationList = new ArrayList<Location>();
		userList = new ArrayList<User>();
		adminList = new ArrayList<Admin>();
		theatreList = new ArrayList<Theatre>();
		screenList = new ArrayList<Screen>();
	}

	public static CinemaDatabase getInstance() {
		if (cinemaDB == null) {
			cinemaDB = new CinemaDatabase();
		}
		return cinemaDB;
	}

	public void addLocationList(Location location) {
		this.locationList.add(location);
	}

	public void deleteLocationList(Location location) {
		this.locationList.remove(location);
	}

	public List<Location> getLocationList() {
		return locationList;
	}

	public void addUserList(User user) {
		this.userList.add(user);
	}

	public void deleteUserList(User user) {
		this.userList.remove(user);
	}

	public List<User> getUserList() {
		return userList;
	}

	public void addAdminList(Admin admin) {
		this.adminList.add(admin);
	}

	public void deleteAdminList(Admin admin) {
		this.adminList.remove(admin);
	}

	public List<Admin> getAdminList() {
		return adminList;
	}

	public void addTheatreList(Theatre theatre) {
		this.theatreList.add(theatre);
	}

	public void deleteTheatreList(Theatre theatre) {
		this.theatreList.remove(theatre);
	}

	public List<Theatre> getTheatreList() {
		return theatreList;
	}

	public void addScreenList(Screen screen) {
		this.screenList.add(screen);
	}

	public void deleteScreenList(Screen screen) {
		this.screenList.remove(screen);
	}

	public List<Screen> getScreenList() {
		return screenList;
	}

	public void addShowsList(ShowTime shows) {
		this.showTimeList.add(shows);
	}

	public void deleteShowsList(ShowTime shows) {
		this.showTimeList.remove(shows);
	}

	public List<ShowTime> getShowsList() {
		return showTimeList;
	}

}
